<clientConfig version="1.1">
  <emailProvider id="yahoo.com">
    <domain>yahoo.com</domain>
    <domain>yahoo.de</domain>
    <domain>yahoo.it</domain>
    <domain>yahoo.fr</domain>
    <domain>yahoo.es</domain>
    <domain>yahoo.se</domain>
    <domain>yahoo.co.uk</domain>
    <domain>yahoo.co.nz</domain>
    <domain>yahoo.com.au</domain>
    <domain>yahoo.com.ar</domain>
    <domain>yahoo.com.br</domain>
    <domain>yahoo.com.mx</domain>
    <domain>ymail.com</domain>
    <domain>rocketmail.com</domain>
    <domain>yahoodns.net</domain>
    <displayName>Yahoo! Mail</displayName>
    <displayShortName>Yahoo</displayShortName>
    <incomingServer type="imap">
      <hostname>imap.mail.yahoo.com</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <incomingServer type="pop3">
      <hostname>pop.mail.yahoo.com</hostname>
      <port>995</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtp.mail.yahoo.com</hostname>
      <port>465</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>password-cleartext</authentication>
    </outgoingServer>
  </emailProvider>
  <webMail>
    <loginPage url="https://mail.yahoo.com"/>
    <loginPageInfo url="https://mail.yahoo.com/">
      <username>%EMAILADDRESS%</username>
      <usernameField id="login-username"/>
      <passwordField id="login-passwd"/>
      <loginButton id="login-signin"/>
    </loginPageInfo>
  </webMail>
</clientConfig>
